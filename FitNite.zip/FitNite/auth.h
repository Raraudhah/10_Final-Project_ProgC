#ifndef AUTH_H
#define AUTH_H

void createAccount();
void login();
void forgotPassword();
int hitungKaloriTarget(char *gender, int umur, int tinggi, int berat, int aktivitasLevel, int *goals);

#endif