#ifndef DASHBOARD_H
#define DASHBOARD_H

void dashboard(const char *email, int targetKalori);
void showWeeklySummary(const char *email, int targetKalori);

#endif